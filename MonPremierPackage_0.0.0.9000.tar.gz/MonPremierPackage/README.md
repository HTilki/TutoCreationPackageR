
# MonPremierPackage

<!-- badges: start -->
<!-- badges: end -->

The goal of MonPremierPackage is to ...

## Installation

You can install the development version of MonPremierPackage like so:

``` r
# FILL THIS IN! HOW CAN PEOPLE INSTALL YOUR DEV PACKAGE?
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(MonPremierPackage)
## basic example code
```

